package org.fenixsoft.jvm.chapter7;

/**
 * @author zzm
 */
public class SubClass extends SuperClass {

    static {
        System.out.println("SubClass init!");
    }
}
